/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package miniyahtzee;

import junit.framework.TestCase;

/**
 *
 * @author blain
 */
public class StraightTest extends TestCase
{
    
    public StraightTest(String testName)
    {
        super(testName);
    }

    public void testGetName()
    {
    }

    public void testCalculateScore()
    {
    }

    public void testCanScore()
    {
    }

    public void testScore()
    {
    }

    public void testReset()
    {
    }

    public void testGetCurrentScore()
    {
    }
    
}
