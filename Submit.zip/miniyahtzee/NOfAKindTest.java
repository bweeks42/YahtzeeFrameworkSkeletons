/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package miniyahtzee;

import java.util.ArrayList;
import java.util.List;
import junit.framework.TestCase;
import yahtzeeframework.JahtzeeDie;

/**
 *
 * @author blain
 */
public class NOfAKindTest extends TestCase
{
    
    public NOfAKindTest(String testName)
    {
        super(testName);
    }

    public void testGetName()
    {
        NOfAKind n = new NOfAKind(3, 1);
        assertEquals("3 of a kind (1 pts)", n.getName());
    }

    public void testCalculateScore()
    {
        List<JahtzeeDie> dice = new ArrayList<>();
        NOfAKind n = new NOfAKind(3, 1);
        assertEquals(0, n.calculateScore(dice));
    }

    public void testCanScore()
    {
        NOfAKind n = new NOfAKind(3, 1);
        assertEquals(true, n.canScore());
    }

    public void testReset()
    {
        NOfAKind n = new NOfAKind(3, 1);
        n.score();
        n.reset();
        assertEquals(true, n.canScore());
    }

    public void testScore()
    {
        NOfAKind n = new NOfAKind(3, 1);
        n.score();
        assertEquals(false, n.canScore());
    }

    public void testGetCurrentScore()
    {
        NOfAKind n = new NOfAKind(3, 1);
        assertEquals(0, n.getCurrentScore());
    }
    
}
