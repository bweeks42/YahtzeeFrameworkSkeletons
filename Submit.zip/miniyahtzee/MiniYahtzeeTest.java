/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package miniyahtzee;

import junit.framework.TestCase;

/**
 *
 * @author blain
 */
public class MiniYahtzeeTest extends TestCase
{
    
    public MiniYahtzeeTest(String testName)
    {
        super(testName);
    }

    public void testGetComboCategories()
    {
        MiniYahtzee mini = new MiniYahtzee();
        assertEquals(2, mini.getComboCategories().size());
    }

    public void testGetBonuses()
    {
        MiniYahtzee mini = new MiniYahtzee();
        assertEquals(1, mini.getBonuses().size());
    }
    
}
