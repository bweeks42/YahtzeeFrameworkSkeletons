/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package rainbowyahtzee;

import junit.framework.TestCase;

/**
 *
 * @author blain
 */
public class NOfAKindTest extends TestCase
{
    
    public NOfAKindTest(String testName)
    {
        super(testName);
    }

    public void testGetName()
    {
    }

    public void testCalculateScore()
    {
    }

    public void testCanScore()
    {
    }

    public void testReset()
    {
    }

    public void testScore()
    {
    }

    public void testGetCurrentScore()
    {
    }
    
}
