/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package rainbowyahtzee;

import junit.framework.TestCase;

/**
 *
 * @author blain
 */
public class RainbowYahtzeeTest extends TestCase
{
    
    public RainbowYahtzeeTest(String testName)
    {
        super(testName);
    }

    public void testGetComboCategories()
    {
    }

    public void testGetBonuses()
    {
    }
    
}
