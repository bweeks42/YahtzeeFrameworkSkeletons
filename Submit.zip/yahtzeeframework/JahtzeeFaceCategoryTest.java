/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package yahtzeeframework;

import junit.framework.TestCase;

/**
 *
 * @author blain
 */
public class JahtzeeFaceCategoryTest extends TestCase
{
    
    public JahtzeeFaceCategoryTest(String testName)
    {
        super(testName);
    }

    public void testCreateCategory()
    {
    }

    public void testGetName()
    {
    }

    public void testCalculateScore()
    {
    }

    public void testScore()
    {
    }

    public void testCanScore()
    {
    }

    public void testReset()
    {
    }

    public void testGetCurrentScore()
    {
    }
    
}
