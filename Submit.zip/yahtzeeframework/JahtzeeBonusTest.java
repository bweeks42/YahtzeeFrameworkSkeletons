/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package yahtzeeframework;

import java.util.List;
import junit.framework.TestCase;

/**
 *
 * @author blain
 */
public class JahtzeeBonusTest extends TestCase
{
    
    public JahtzeeBonusTest(String testName)
    {
        super(testName);
    }

    public void testGetScore()
    {
    }

    public class JahtzeeBonusImpl implements JahtzeeBonus
    {

        public int getScore(List<JahtzeeCategory> faces, List<JahtzeeCategory> combos)
        {
            return 0;
        }
    }
    
}
