/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package yahtzeeframework;

import junit.framework.TestCase;

/**
 *
 * @author blain
 */
public class ScoreRowTest extends TestCase
{
    
    public ScoreRowTest(String testName)
    {
        super(testName);
    }

    public void testSetFields()
    {
    }

    public void testSetVisible()
    {
    }

    public void testSetEnabled()
    {
    }
    
}
