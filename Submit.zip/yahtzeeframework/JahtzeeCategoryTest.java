/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package yahtzeeframework;

import java.util.List;
import junit.framework.TestCase;

/**
 *
 * @author blain
 */
public class JahtzeeCategoryTest extends TestCase
{
    
    public JahtzeeCategoryTest(String testName)
    {
        super(testName);
    }

    public void testGetName()
    {
    }

    public void testGetCurrentScore()
    {
    }

    public void testCalculateScore()
    {
    }

    public void testCanScore()
    {
    }

    public void testScore()
    {
    }

    public void testReset()
    {
    }

    public class JahtzeeCategoryImpl implements JahtzeeCategory
    {

        public String getName()
        {
            return "";
        }

        public int getCurrentScore()
        {
            return 0;
        }

        public int calculateScore(List<JahtzeeDie> dice)
        {
            return 0;
        }

        public boolean canScore()
        {
            return false;
        }

        public void score()
        {
        }

        public void reset()
        {
        }
    }
    
}
