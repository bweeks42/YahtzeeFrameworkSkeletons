/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package yahtzeeframework;

import java.util.List;
import junit.framework.TestCase;

/**
 *
 * @author blain
 */
public class JahtzeeGameTest extends TestCase
{
    
    public JahtzeeGameTest(String testName)
    {
        super(testName);
    }

    public void testGetComboCategories()
    {
    }

    public void testGetBonuses()
    {
    }

    public class JahtzeeGameImpl implements JahtzeeGame
    {

        public List<JahtzeeCategory> getComboCategories()
        {
            return null;
        }

        public List<JahtzeeBonus> getBonuses()
        {
            return null;
        }
    }
    
}
