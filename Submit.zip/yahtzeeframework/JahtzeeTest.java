/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package yahtzeeframework;

import junit.framework.TestCase;

/**
 *
 * @author blain
 */
public class JahtzeeTest extends TestCase
{
    
    public JahtzeeTest(String testName)
    {
        super(testName);
    }

    public void testGetDiceLimit()
    {
    }

    public void testCanRoll()
    {
    }

    public void testIsGameOver()
    {
    }

    public void testCanMoveDice()
    {
    }

    public void testGetDiceInPlay()
    {
    }

    public void testGetFaceCategories()
    {
    }

    public void testGetComboCategories()
    {
    }

    public void testCanScore()
    {
    }

    public void testGetFaceScore()
    {
    }

    public void testGetComboScore()
    {
    }

    public void testGetTotalScore()
    {
    }

    public void testIsBonus()
    {
    }

    public void testGetRollCount()
    {
    }

    public void testGetRolled()
    {
    }

    public void testGetHeld()
    {
    }

    public void testProcessCommand()
    {
    }
    
}
